package Sprint3.InlämningsUppgift1;

import javax.swing.*;


public class Main extends JFrame {

    public static void main(String[] args){

        exec e = new exec();

    }
}
